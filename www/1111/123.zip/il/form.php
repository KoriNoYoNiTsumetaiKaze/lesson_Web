<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<title>form</title>
</head>

<body>
<form>
<input type="text" name=" "/>
<br/>
password<input type="password" name=" "/>
<br/>       
file<input type="file" name=" "/>
<br/>
hidden<input type="hidden" name=" " value=" " />
<br/>
radio<input type="radio" name="ss" value=" " />
<br/>
radio<input type="radio" name="ss" value=" " />
<br/>
checkbox<input type="checkbox" name="" value="  " />
<br/>
reset<input type="reset" name="" value="reset" />
<br/>
button<input type="button" name="" value="help" />
<br/>
submit<input type="submit" name="" value="  " />
<br/>
image<input type="image" name="" src="C:\Users\Public\Pictures\Sample Pictures/Chrysanthemum.jpg" />
<br/>
<select name=" ">
<option value=" ">
text
</option>
<option value="">
mail
</option>
</select>
<textarea name="" cols="10" rows="5">
</textarea>


</form>
</body>
</html>