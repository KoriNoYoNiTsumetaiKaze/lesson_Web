<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<title>�������� ��� ��������</title>
</head>

<body>
<?php
//echo date("d.m.Y");
echo max(0,2000000);
echo "<br/>";
echo min(0,2000000);
echo "<br/>";
echo rand(456123,20000000);
echo "<br/>";
echo round(3.1455,2);
echo "<br/>";
echo ceil(9.14);
echo "<br/>";
echo floor(15.99);
?>
</body>
</html>