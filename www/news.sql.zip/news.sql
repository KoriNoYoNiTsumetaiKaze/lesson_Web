-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 07, 2013 at 08:44 PM
-- Server version: 5.1.40
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `firstdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `dates` varchar(15) NOT NULL,
  `names` varchar(150) NOT NULL,
  `texts` varchar(200) NOT NULL,
  `hot` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `dates`, `names`, `texts`, `hot`) VALUES
(1, '2013/10/07', 'новость 1', 'В начале было Слово', 1),
(2, '2013/10/05', 'новость 2', '123', 0),
(3, '1970/01/01', 'Начало Эры', 'И пришел Юникс!', 1),
(4, '2013/01/01', 'Всех с новым годом!', '', 1),
(6, '&lt;b&gt;1&lt;/', '', '', 0),
(7, '', '<b>eee</b>', '', 1),
(8, '', '<a>www</a>', '', 1),
(9, '', '', 'fff      ggg', 1),
(10, '', 'TYPE', '', 0),
(11, '', 'QQQ', 'Fgfnfjnh Gkrgj Rkgjr Rj Rrr', 1);
