-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2013 at 07:08 PM
-- Server version: 5.1.40
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test_site_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `php_news`
--

CREATE TABLE IF NOT EXISTS `php_news` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `chislo` varchar(15) NOT NULL,
  `tema` varchar(200) NOT NULL,
  `tekst` varchar(1000) NOT NULL,
  `image` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `php_news`
--

INSERT INTO `php_news` (`id`, `chislo`, `tema`, `tekst`, `image`) VALUES
(14, '3222222222', '2222', '    3efrgfh		', ''),
(13, '234324', '234234', '   	23432324324	', ''),
(12, '32423342', '423423432', '  	324234	', ''),
(15, '12.345.64', 'lfgkdf;lg', ' 		g;ldf;blblvmbv.b', ''),
(16, '323', '213', ' 		efgg', ''),
(17, '', '', '		', 'Lighthouse.jpg');
